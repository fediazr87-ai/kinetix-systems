@echo off
title Lanzador Oficial - Kinetix Gym ERP Pro
set "APP_URL=https://kinetix-gym-erp.vercel.app"

if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" (
    start "" /max "C:\Program Files\Google\Chrome\Application\chrome.exe" --start-maximized --app="%APP_URL%"
    exit
)
if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" (
    start "" /max "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" --start-maximized --app="%APP_URL%"
    exit
)
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
    start "" /max "%LocalAppData%\Google\Chrome\Application\chrome.exe" --start-maximized --app="%APP_URL%"
    exit
)
if exist "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" (
    start "" /max "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --start-maximized --app="%APP_URL%"
    exit
)
if exist "C:\Program Files\Microsoft\Edge\Application\msedge.exe" (
    start "" /max "C:\Program Files\Microsoft\Edge\Application\msedge.exe" --start-maximized --app="%APP_URL%"
    exit
)
start "" /max "%APP_URL%"
