@echo off
title Lanzador Oficial - Kinetix Med & Booking Suite (Expedientes, Consultas, Citas y Recordatorios)
set "APP_PATH=%~dp0Kinetix_Med_Expedientes_Citas.html"
if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" (
    start "" /max "C:\Program Files\Google\Chrome\Application\chrome.exe" --start-maximized --app="file:///%APP_PATH%"
    exit
)
if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" (
    start "" /max "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" --start-maximized --app="file:///%APP_PATH%"
    exit
)
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
    start "" /max "%LocalAppData%\Google\Chrome\Application\chrome.exe" --start-maximized --app="file:///%APP_PATH%"
    exit
)
if exist "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" (
    start "" /max "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --start-maximized --app="file:///%APP_PATH%"
    exit
)
if exist "C:\Program Files\Microsoft\Edge\Application\msedge.exe" (
    start "" /max "C:\Program Files\Microsoft\Edge\Application\msedge.exe" --start-maximized --app="file:///%APP_PATH%"
    exit
)
start "" /max "%APP_PATH%"
