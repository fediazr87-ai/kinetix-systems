@echo off
title Lanzador Oficial - Kinetix POS, Facturación & Control de Inventarios v3.0
set "APP_PATH=%~dp0Kinetix_POS_Facturacion_Inventario.html"
if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" (
    start "" /max "C:\Program Files\Google\Chrome\Application\chrome.exe" --start-maximized --app="file:///%APP_PATH%"
    exit
)
if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" (
    start "" /max "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" --start-maximized --app="file:///%APP_PATH%"
    exit
)
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
    start "" /max "%LocalAppData%\Google\Chrome\Application\chrome.exe" --start-maximized --app="file:///%APP_PATH%"
    exit
)
if exist "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" (
    start "" /max "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --start-maximized --app="file:///%APP_PATH%"
    exit
)
if exist "C:\Program Files\Microsoft\Edge\Application\msedge.exe" (
    start "" /max "C:\Program Files\Microsoft\Edge\Application\msedge.exe" --start-maximized --app="file:///%APP_PATH%"
    exit
)
start "" /max "%APP_PATH%"
