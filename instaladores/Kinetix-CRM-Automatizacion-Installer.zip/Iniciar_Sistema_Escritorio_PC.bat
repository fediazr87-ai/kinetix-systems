@echo off
title Lanzador Oficial - Kinetix CRM, Captación de Leads, Cotizaciones PDF & Automatización
set "APP_PATH=%~dp0Kinetix_CRM_Cotizador_Automatizacion.html"
if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" (
    start "" /max "C:\Program Files\Google\Chrome\Application\chrome.exe" --start-maximized --app="file:///%APP_PATH%"
    exit
)
if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" (
    start "" /max "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" --start-maximized --app="file:///%APP_PATH%"
    exit
)
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
    start "" /max "%LocalAppData%\Google\Chrome\Application\chrome.exe" --start-maximized --app="file:///%APP_PATH%"
    exit
)
if exist "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" (
    start "" /max "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --start-maximized --app="file:///%APP_PATH%"
    exit
)
if exist "C:\Program Files\Microsoft\Edge\Application\msedge.exe" (
    start "" /max "C:\Program Files\Microsoft\Edge\Application\msedge.exe" --start-maximized --app="file:///%APP_PATH%"
    exit
)
start "" /max "%APP_PATH%"
